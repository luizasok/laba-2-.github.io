$(document).ready(function(){

	$("a[rel^='gallery']").prettyPhoto();
	
	$(document).pngFix(); 
	
	function mycarousel_initCallback(carousel)
	{
    	// Disable autoscrolling if the user clicks the prev or next button.
    	carousel.buttonNext.bind('click', function() {
    	    carousel.startAuto(0);
    	});
		
    	carousel.buttonPrev.bind('click', function() {
    	    carousel.startAuto(0);
    	});
		
    	// Pause autoscrolling if the user moves with the cursor over the clip.
    	carousel.clip.hover(function() {
    	    carousel.stopAuto();
    	}, function() {
    	    carousel.startAuto();
    	});
	};


    	jQuery('#mycarousel').jcarousel({
    	    auto: 6,
    	    wrap: 'last',
    	    animation: 'slow',
    	    initCallback: mycarousel_initCallback
    });

});